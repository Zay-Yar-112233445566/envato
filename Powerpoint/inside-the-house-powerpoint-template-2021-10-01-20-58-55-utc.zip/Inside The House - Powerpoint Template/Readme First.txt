FONT USED IN THIS TEMPLATE :

Abril Fatface - https://fonts.google.com/specimen/Abril+Fatface
Source Sans Pro - https://fonts.google.com/specimen/Source+Sans+Pro

-----------------------------------------------------

The photos used in the preview are not included.
Free font used.

Hope you Like it.
Dont Forget to rate.
Thanks.

Contact Us: ---> Vunira.project@gmail.com


